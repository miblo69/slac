#!/usr/bin/perl
# $Header: /usr/local/secsrch/RCS/secsrch.pl,v 1.68 2003/07/03 11:48:10 mibl Exp mibl $
# $Revision: 1.68 $
# (C) Mike Blomgren 2001-02-21
# mibl@a51.mine.nu
# 
# A Perl script to parse Webserver logfiles, and search for
# any security anomalies, and report them accordingly, thus SecSrch.
# The script is intended to be used offline, i.e. to sift through
# 'yesterdays' access.log in a cron job, or at will.
#
# Handles 'Common Log Format' (e.g. Weblogic), Standard IIS (IN??????.LOG),
# IIS Extended logfiles etc.
# It should be fairly simple to add other logformats (if you know Perl...)
# 
# This script comes with the standard disclaimers. I.e.
# there are no warranties or guaranties whatsoever.
# Use at your own risk, and if it causes problems - your loss.
# You are free to use the script for personal use. 
# 
# 
# 2000-12-15 Start: First attempt att writing a logfile parser...
# 2001-01-29 Added: Support for mulitiple .gz files with wildcards ex: secsrch.pl apwww1*.gz
# 2001-01-30 Added: Counter for # of unique IP's
# 2001-01-30 Added: Counter for # of status codes
# 2001-02-08 Cleaned: Cleaned out comments, and unnecessary 'testing' code.
# 2001-02-19 Released: 2.13 Initial public release.
# 2001-02-25 Added: Count of HTTP versions. Stripped " from URL.
# 2001-02-28 Added: Optional FQDN name resolution.
# 2001-03-02 Changed: Reports now contain headers, thus shorter lines
# 2001-04-16 2.20 Added: Hits/Hour - for a general 'feel' of the visitors hours.
# 2001-04-16 2.21 Added: Top HIT'ers.
# 2001-04-26 2.22 Added: Percent of total, to TOP HIT'ers
# 2001-05-10 2.23 Added: -N switch to not perform name resolution
# 2001-06-14 2.24 Bug: Handling of 'Succesful Downloads' had logic error.
# 2001-08-20 2.25 Added: $CRLF variable to accomodate for unix & DOS output format
# 2001-09-03 2.26 Added: Rank on 'Top HIT'ers' list
# 2002-05-22 2.27 Started rework for 'logger' function
# 2002-06-10 2.28 Added syslog logging of progress
#                 Added Cookie hijacking detection
# 2002-06-16 2.29 Added detection of URI Query manipulation attempts
# 2002-08-03 2.30 Various improvements
# 2003-03-18 2.31 Started working on long-time statistics gathering
# 2003-03-22 2.32 Also added XML output, but this is not finished in any way.
# 2003-04-03 2.33 Gave up on XML. This is really crossing the river for water.
# 2003-06-02 2.35 Added XML again... Maybe I can find it usefull after all...
# 2003-06-29 2.37 Added detection of  XSS scripting attmpts
# 
# To Do...:
# Add 'Bursty surfing detection' 
# Add 'Crawler detection'
# Improve parsing performance. 2000-4000 lines/second is not impressive...
#   and the parsing is what sucks all performance.
# Add XML modularized output for easy ASCII/HTML/whatever output
# Add Analysis based on time - WHEN do 5xx errors occur, etc? Related to a single time, or spread out during the day
# Add maximum hits per a single second (to locate possile resource starvation attempts)
# Look for any delays in traffic (log times without any hits) - To locate succesful DoS, or just 'down-times'
# Do Whois-lookup on IP-addresses in printed in report. (Whith GeekProxy maybe?)
# Add Automatic detection and split of logfiles which contain data from several webservers
# When listing logged in users, check at which times they are logged in.

$VERSION = '2.38';

$res = 'true';  # Set to true if we should attempt to resolve IP's to FQDN
#$res = 'false';

# Select Output-format (DOS or Unix - CRLF or CR)
#$CRLF = "\r\n";  # 0x0D 0x0A  (DOS-format)
$CRLF = "\n";  # 0x0A (Unix -format)
$iisext = 0;   #Boolean value for handling IIS Extended Logs.

# Required to handle compressed files. Remove if not needed...
use Compress::Zlib;
use Getopt::Std;
use Socket;   ## For dns resolver
use Archive::Zip qw ( :CONSTANTS );
#use Archive::Zip::Member;
use Benchmark;
use Time::HiRes;
$timing = 0;  # Used for debug purposes to find time-consuming operations

use URI::Escape;

use Sys::Syslog;                          # all except setlogsock, or:
use Sys::Syslog qw(:DEFAULT setlogsock);  # default set, plus setlogsock

# For graphing functions. Comment out if not needed
#use GD::Graph::bars;
#use GD::Graph::hbars;
#use GD::Graph::Data;

use XML::Writer;
use IO;

slog('Starting Exec');

getopts('WhvNpsXoC:');  
# h - only print help
# v - print version and exit
# N - don't do name lookups
# s - Only print stats
# X - Use XML output for report
# o - Overwrite output file if it exists
# C - CustomLog Configuration
# W - being run as a CGI (Use <br>\n as $CRLF)
# p - Print a descriptive text for each report section

slog("CustomLog Opts: $opt_C $opt_p");

if ($opt_W ne '') {
    $CRLF = "<br>\n";
}

# Print descriptions?
if ($opt_p ne '') { $pdesc = 1; } else { $pdesc = 0 }

#getopts('v');

#print $opt_C;
#exit;

# Check which environment we're running in
if ($ENV{'OS'} =~ m/windows/i) {
    $os = 'win'; 		#Windows
    $osenv = 'OS';
}
elsif ($ENV{'OSTYPE'} =~ m/solaris/i) {
    $os = 'sol';		#Solaris
    $osenv = 'OSTYPE';
}
else {  
    $os = 'unknown';
}

#print "Assumed $os. Running under $ENV{"$osenv"}\n" ;


# Hash with Months - This is to map names to numbers.
# Needs to be altered if non-english... 
# (A 'use locale' procedure might work, but I haven't tried....)
%MONS = ( 'Jan' => '01', 'Feb' => '02', 'Mar' => '03', 
	  'Apr' => '04', 'May' => '05', 'Jun' => '06',
	  'Jul' => '07', 'Aug' => '08', 'Sep' => '09', 
	  'Oct' => '10', 'Nov' => '11', 'Dec' => '12');

# Hash with HTTP status Codes. Mostly for reference. Only the first word in 
# capital letters is actually printed in the results...
%STATCODE = ( '100' => 'CONTINUE', 
	      '101' => 'SWITCH_PROTOCOLS', 
	      '200' => 'OK', 
	      '201' => 'CREATED', 
	      '202' => 'ACCEPTED', 
	      '203' => 'PARTIAL', 
	      '204' => 'NO_CONTENT', 
	      '205' => 'RESET_CONTENT', 
	      '206' => 'PARTIAL_CONTENT', 
	      '300' => 'AMBIGUOUS', 
	      '301' => 'MOVED', 
	      '302' => 'REDIRECT', 
	      '303' => 'REDIRECT_METHOD', 
	      '304' => 'NOT_MODIFIED', 
	      '305' => 'USE_PROXY',
	      '307' => 'REDIRECT_KEEP_VERB', 
	      '400' => 'BAD_REQUEST', 
	      '401' => 'DENIED', 
	      '402' => 'PAYMENT_REQ', 
	      '403' => 'FORBIDDEN', 
	      '404' => 'NOT_FOUND', 
	      '405' => 'BAD_METHOD', 
	      '406' => 'NONE_ACCEPTABLE', 
	      '407' => 'PROXY_AUTH_REQ', 
	      '408' => 'REQUEST_TIMEOUT',
	      '409' => 'CONFLICT', 
	      '410' => 'GONE', 
	      '411' => 'LENGTH_REQUIRED', 
	      '412' => 'PRECOND_FAILED',
	      '413' => 'REQUEST_TOO_LARGE', 
	      '414' => 'URI_TOO_LONG', 
	      '415' => 'UNSUPPORTED_MEDIA', 
	      '416' => 'NOT SATISFIABLE',
	      '417' => 'EXPECTATION FAILED',
	      '449' => 'RETRY_WITH', 
	      '500' => 'SERVER_ERROR', 
	      '501' => 'NOT_SUPPORTED', 
	      '502' => 'BAD_GATEWAY',
	      '503' => 'SERVICE_UNAVAILABLE', 
	      '504' => 'GATEWAY_TIMEOUT', 
	      '505' => 'VERSION_NOT_SUPPORTED');

$URL_MAX = 400;       # Max length of URLs to warn of if exceeding this length
$SITE = 'http://a51.mine.nu/';
$SITE_DIR = '';

$mindate = '';
$maxdate = '';

$starttime = time;
$starttimetext = localtime;

$infile = $ARGV[0];

if (sanitize($infile) ne 0) { die "Invalid characters found in filename. The error is logged.\n";}

$outfile = $ARGV[1];
if (sanitize($outfile) ne 0) { die "Invalid charcaters found in filename. The errror is logged.\n"; }

$statsfile = '/tmp/stats.log';
$statsfile = '&STDOUT';
slog('Infile: ' . $infile);

$topmax = 20;		# How many 'TOP HIT'ers' to display

# Check if we want help....
if ($opt_h eq 1) {
    print "SecSrch version $VERSION$CRLF";
    print "Useage: [cat\|type] \<infile\> \| [perl] secsrch.pl \- [outfile]\n";
    print "or      [perl] secsrch.pl [\-Nvhs] <infile> [outfile]$CRLF";
    print "or      [perl] secsrch.pl [\-Nvhs] \'<infile\*.gz>\' [outfile]$CRLF$CRLF";
    print "or      [perl] secsrch.pl [\-Nvhs] \'<infile\*.gz>\' [outdir]$CRLF$CRLF";
    print "If \-N is used, Name resolution will not be performed. $CRLF";
    print "If \'\-\' is used for <infile>, STDIN will be used for input.$CRLF";
    print "If \'\-\' is used for <outfile>, STDOUT will be used for output.$CRLF$CRLF";
    exit;
}

#Check for version info
if ($opt_v eq 1) {	
    print "$CRLFSecSrch by Mike Blomgren, v$VERSION$CRLF";	
    exit; 
}



# Which files do we open?....
if ($infile eq '-') {
    @list = '-';
    if (($outfile eq '') || ($outfile eq '-'))
    {	
	$outfile = '&STDOUT';	
    }
    # Else outfile = outfile...
} else {
    @list = glob $infile;   # Did we specify wildcard
    
    if (join( '', @list) eq "") {
	slog("No Files found matching $infile.$CRLF");
	die "No Files found matching $infile.$CRLF";
    }
    $list[0] =~ m/[\/\\]*?([\d\.\w\-\_]+)$/;
    # If '-' specified as outfile, then open STDOUT
    if ($outfile eq '-') {
	$outfile = '&STDOUT';
    }
    elsif ($list[1] ne '')
    {	# If more than one file is being analyzed - use a different output filename,
	# to indicate that multiple files have been analyzed into one result file.		
	if ( -d $outfile) {
	    $outfile = $outfile . '/SecSrch.Multi.' . $1 . '.log';
	} else {
	    if ($outfile eq '') {	
		$outfile = 'SecSrch.Multi.' . $1 . '.log';
	    }
	}	
    }
    else
    {	# If only one infile, use 'standard' output filename.
	if ($outfile eq '')
	{
	    $outfile = 'SecSrch.' . $1 . '.log';
	}
	if ( -d $outfile ) 
	{
	    $outfile = $outfile . '/SecSrch.' . $1 . '.log';	
	}
	# Else $outfile = $outfile...
    }
    
}

if ((-f $outfile) && !($opt_o))
{
    print "File \'$outfile\' already exists. Exiting.$CRLF$CRLF";
    exit ;
}

open (OUT , ">$outfile") || die "Can't open $outfile for output\.";
open (STATS, ">$statsfile") || die "Can't open $statsfile for output\.";
#print "Infile(s): " . join (" $CRLF",@list) . " $CRLFOutfile: $outfile $CRLF";
	
foreach $file (@list)
{ 
    slog("Starting with: $file");
    if ($file =~ m/\.gz$/)
    {
	slog('Compressed .gz file detected');
	$gz = gzopen($file, "rb") or die "Cannot open $file: $gzerrno$CRLF" ;
	while ($gz->gzreadline($buffer) > 0)
	{
	    $_ = $buffer;
	    # Can we parse the current line? 
	    if (splitline() != -1)
	    {
		# Yepp, then make statistics...
		makestats();
	    }
	}
	die "Error reading from $file: $gzerrno$CRLF" if $gzerrno != Z_STREAM_END ;
	$gz->gzclose() ;
    } 
    #elsif ($file =~ m/\.zip$/) {
    #slog("Zip File");
    #$zip = Archive::Zip->new();
    #die 'read error' unless $zip->read($file) == AZ_OK;
    #my @member = $zip->memberNames();
    #print $zip->numberOfMembers();
    ##print $zip->memberNames;
    #foreach $x (@member) {
    #    print "$x\n";
    #    $zip->extractMember($x, '/tmp/' . $x);
    
    # Open and start reading extracted file
    #    open (IN, "</tmp/$x") || die "Can't open $file for input.$CRLF";
    #    while (<IN>)
    #    {
    #	# Can we parse the current line?
    #	if (splitline() != -1) {
    #	    if (($date le $mindate) || ($mindate eq '')) {$mindate = $date};
    #	    if (($date gt $maxdate) || ($maxdate eq '')) {$maxdate = $date};
    #	    # Yepp, then make statistics...
    #	    makestats();
    #	}
    #    }
    #    close IN;
    #} 
    #}
    else {
	if ($file eq '-') {$infile = '&STDIN'};
	open (IN, "<$file") || die "Can't open $file for input.$CRLF"; 
	#Start reading file
	while (<IN>) 
	{		
	    # Can we parse the current line? 
	    if (splitline() != -1) {
		#if (m/getting/) {print "problems: $_"; exit;}
		if (($date le $mindate) || ($mindate eq '')) {$mindate = $date};
		if (($date gt $maxdate) || ($maxdate eq '')) {$maxdate = $date};
		# Yepp, then make statistics...
		makestats();
		#print "returned\n";
	    }
	}	
	close IN;
    }	
}

if ($opt_s) {
    printstats();
} else {
    if ($opt_X) {
	printxml();
    } else {
	printall();
    }
}

slog('Exiting...');
exit 0;


sub splitline {
    $numlines++;
    #print "$timing\n";
    undef $serverip, $ip, $status, $date, $referer, $cookie, $uri, $url, $user, $httpver, $servername;
    if ($timing == 1) {
	my $t0 = new Benchmark;
	print "$t0\n";
    }
	
    # Split Logfile line into values.
    
    # Check for lines with comments
    if (m/^\s*?\#/) {
	#$badlines++;
	#$logformat{'Ignored'}++;
	if (m/^\s*\#Fields\:\s(.*)/) {
	    $logformat{'Field definitions'}++;
            @header = split(/\s/, $1);
            #print join("\n",@header);
            $iisext = 1;   # If we see a #Field line, we assume the whole file
	                   # is IIS Extended format. And set that assumption here.
        }
	else
	{
	    $logformat{'Ignored Comments'}++;
	}
	if (m/^\#Date\: (\d\d\d\d\-\d\d\-\d\d)\s(\d\d\:\d\d:\d\d)/) {
	    $exdate = $1;
	    #print "Assuming IIS EX file: $1 - $2$CRLF";
	}
	return -1;
    }

    if ($iisext eq 1) {
	#if (m/getting/) {print; print "problems"; exit;}
	$logformat{'MS-IIS Extended'}++;
	# Check for the pesky NULL lines in IIS log files
	if ((tr/\x00//)) { return -1};
	undef %HASH;
	@fields = split /\s/;
	#print join("\n",@fields);
	#if (m/getting/) {
	#    print; 
	#    print "problems"; 
	#    print join("\n",@fields);
	#    exit;
	#}
	$c = 0;
	foreach $x (@header) {
	    #print "$x $fields[$c]\n";
	    @HASH{$x} = $fields[$c];
	    $c++;
	}
	$ip = $HASH{'c-ip'};
	# Sanity Check
	if (not $ip =~ m/\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/) {
	    #print "no match\n";
	    return -1;
	}
	$url = $HASH{'cs-method'} . ' ' . $HASH{'cs-uri-stem'};
	$method = $HASH{'cs-method'};
	#if ($method eq '-') {print "Illegal: $_\n"}
	$query = $HASH{'cs-uri-query'};
	#print "IIS Q: $query\n";
	$user = $HASH{'cs-username'} unless not defined $HASH{'cs-username'};
	$sitename = $HASH{'s-sitename'};
	$serverip = $HASH{'s-ip'};
	if ( (not $serverip =~ m/\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/)) {
            #print "no match\n";
            return -1;
        }
 
	$cname = $HASH{'s-computername'};
	$date = $HASH{'date'} . ' ' . $HASH{'time'};
	#if ($date =~ m/get/) {
	#    print;
	#}
	$httpver = $HASH{'cs-version'};
	$status = $HASH{'sc-status'};
	$referer = $HASH{'cs(Referer)'} unless not defined $HASH{'cs(Referer)'};
	$cookie = $HASH{'cs(Cookie)'} unless not defined $HASH{'cs(Cookie)'};
	$browser = $HASH{'cs(User-Agent)'};
	$len = $HASH{'sc-bytes'} + $HASH{'cs-bytes'};

	# Modi by MB 030416:
	#$date =~ m/(\d\d\d\d)\-(\d\d)\-(\d\d)\s(\d\d)\:(\d\d)\:(\d\d)/;
	#$day = $3; $mon = $2; $yr = $1; $hr = $4; $mi = $5; $se = $6;
	if ($date =~ m/(\d\d\d\d)\-(\d\d)\-(\d\d)\s(\d\d)\:(\d\d)\:(\d\d)/) {
	    $day = $3; $mon = $2; $yr = $1; $hr = $4; $mi = $5; $se = $6;
	}

	#print "$HASH{'time'}\n";
	$uri = $url . '?' . $query;
	#if ($timing == 1) {
	#    my $t1 = new Benchmark;
	#    print "Splitline: ".timestr(timediff($t1,$t0));
	#}
	return;
    } 
    else {
	
    # Common Log Format (Weblogic, Apache etc)
	if ( m/^(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})   # IP Address
	     \s([\w\d\-]+?)                        # User
	     \s([\-]+?)                        # unused
	     \s(\[.+\])                     # Date
	     \s\"(.+?)\"                    # Url
	     # Match regardless of HTTP Version.
	     \s(\d+?)                       # Statuscodes
	     \s([\-\d]+?)                   # Size
	     \s(?:\"(.*?)\")?                    # Optional Referer
	     (?:\s\"(.*?)\")?                    # Optinal Browser type
	     (?:\s\"(.*?)\")?               # Optional Cookie
	     /iox )                    
	{
	    
	    $logformat{'Common Log Format'}++;
	    $ip = $1; $na1 = $2; $user=$3; $date = $4;
	    $url = $5; 
	    $status = $6; $len = $7;
	    #print "DBG: $url\n";
	    #$query = $6;
	    #$httpver = $7;
	    $referer = $8; $browser = $9; $cookie = $10;
	    $uri = $url . '?' . $query;
	    #print "$httpver\n";
	    if ($url =~ m/([\w\d]+)\s(.*)\s(.*)/iox) {
		$method = $1;
		$url = $2;
		$httpver = $3;
		#print "M: $method\nU:$url\n";
	    }
	    if ($url =~ m/(.*)\?(.*)/) {
		$query = $2;
		#print "Q: $query";
	    }

	    if ( $date =~ m/^\[(\d{1,2})
		 \/(.{3})
		 \/(\d\d\d\d)
		 \:(\d+?)
		 \:(\d+?)
		 \:(\d+?)
		 \x20(.+?)\]/ox)
	    {
		$day = $1; $mon = $2; $yr = $3; $hr = $4; $mi = $5; $se = $6;
		$date = "$yr\-$MONS{$mon}\-$day $hr:$mi:$se";
		$epochtime = "";
	    }
	    return 1;
	}

	elsif ( m/(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})   # Client IP 
	    \s(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})     #Srv IP
	    \s([\-]+?)                        # Unused
            \s(.+?)                        # User
            \s(\[.+\])                     # Date
            \s\"(.*)\"               # Url
	    # (?:(\?.*\s))?
            # (?:(.*?)\")?                 # Match regardless of HTTP Version.
            \s([\d\-]+?)                       # Statuscodes
            \s([\-\d]+?)                   # Size
	    \s(.*?)                         # Unused...
            \s\"(.*?)\"                    # Optional Referer
            \s\"(.*?)\"                    # Optinal Browser type
            \s\"(.*?)\"               # Optional Cookie
            /iox )
        {
	    $logformat{'Apache Custom Combined'}++;
	    $ip = $1;
	    $serverip = $2;
	    $user = $4;
	    $date = $5; 
            $url = $6; $status = $7; $len = $8; $referer = $10;
	    $browser = $11; $cookie = $12;
	    #print "$cookie\n";
            #print "$6";
            if ($url =~ m/([\w\d]+)\s(.*)\s(.*)/iox) {
                $method = $1;
                $url = $2;
                $httpver = $3;
                #print "M: $method\nU:$url\n";
            }
            if ($url =~ m/(.*)\?(.*)/) {
                $query = $2;
                #print "Q: $query";
            }

            if ( $date =~ m/^\[(\d{1,2})
                 \/(.{3})
                 \/(\d\d\d\d)
                 \:(\d+?)
                 \:(\d+?)
                 \:(\d+?)
                 \x20(.+?)\]/ox)
            {
                $day = $1; $mon = $2; $yr = $3; $hr = $4; $mi = $5; $se = $6;
                $date = "$yr\-$MONS{$mon}\-$day $hr:$mi:$se";
                $epochtime = "";
            }
	    return 1;
	}
	
	#IIS Logs Standard Logs (INxxxxxx.log)
	elsif (m/^(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})
	       \,\s*(.+?)
	       \,\s(\d{2,4}).(\d{1,2}).(\d{1,2})
	       \,\s(\d+):(\d\d:\d\d)
	       \,\s([\w\d]+?)
	       \,\s(\w+?)
	       \,\s(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})
	       \,\s(\d+?)
	       \,\s(\d+?)
	       \,\s(\d+?)
	       \,\s(\d+?)
	       \,\s(\d+?)
	       #\,\s(\w+?)
	       \,\s(.+?) 
	       \,\s(.+?)
	       \,.*/ox)
	{
	    $logformat{'IIS Standard'}++;
	    $hr = sprintf("%02d", $6);
	    $ip = $1; $user=$2; $date = "$3-$4-$5 $hr:$7" ;
	    #print "D $date\n";
	    $url = $16 . ' ' . $17; $status = $14; $len = $10;
	    $method = $16;
	    undef $httpver;
	    return 1;

	} 

	elsif ( m/(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})   # Client IP
		\s(.+?)         # Virtual Server
            \s(.+?)                        # Unused
            \s(\[.+\])                     # Date
            \s\"(.*)\"               # Url
            \s([\d\-]+?)                       # Statuscodes
            \s([\-\d]+?)                   # Size
            \s\"(.*?)\"                    # Optional Referer
            \s\"(.*?)\"                    # Optinal Browser type
            /iox )
        {
            $logformat{'Domino Extended'}++;
            $ip = $1;
            $serverip = $2;
            $user = $3;
            $date = $4;
            $url = $5; $status = $6; $len = $7; $referer = $8;
            $browser = $9; #$cookie = $12;
            #print "$cookie\n";
            #print "$6";
            if ($url =~ m/([\w\d]+)\s(.*?)\s(.*)/iox) {
                $method = $1;
                $url = $2;
                $httpver = $3;
                #print "M: $method\nU:$url\n";
            }
            if ($url =~ m/(.*)\?(.*)/) {
                $query = $2;
                #print "Q: $query";
            }

	    if ( $date =~ m/^\[(\d{1,2})
                 \/(.{3})
                 \/(\d\d\d\d)
                 \:(\d+?)
                 \:(\d+?)
                 \:(\d+?)
                 \x20(.+?)\]/ox)
            {
                $day = $1; $mon = $2; $yr = $3; $hr = $4; $mi = $5; $se = $6;
                $date = "$yr\-$MONS{$mon}\-$day $hr:$mi:$se";
                $epochtime = "";
            }


	}
	
	# No Match...

	else 
	{
	    print;
	    $logformat{'Unknown'}++;
	    #$badlines++;
	}
    }
    #if ($timing == 1) {
#	my $t1 = new Benchmark;
#	print "Splitline: ".timestr(timediff($t1,$t0));
#	
#    }
	    
}

sub makestats {
    # Start collecting stats on the parsed logfile entries

    # Check for Exceedingly Long URL's before doing more statistics
    if ((length $url) > $URL_MAX ) {
	$lenu = length($url);
        $url = substr($url, 0, 15) . ' [ Truncated ] ' . substr($url, length($url)-15,15);
        $s18{"$url�$ip�$lenu�$status"}++;
    }
    
    
    # Look for 'File not found' or 'Forbidden' messages, but filter 
    # out the obvious 404 generators...
    if (($status =~ m/404|403|406|400/))
	#&& (not $url =~ m/favicon|GET.\/images|\/img\/meny/ix))
    {
	$s0{"$ip�$url"}++;
	$s01{"$status�$url"}++;
	$s02{"$ip"}++;
	# Why do we resolve the ip-address here??? /Mike
	if ($sip{$ip} eq undef) {	$sip{$ip} = resolve($ip) };
    }
    
    # Logged In Users
    if (defined $user) {
	if (($user ne '-') and ($user ne 'N/A'))
	{
	    $s1{"$user�$ip"}++;
	    # Why do we resolve the ip-address here??? /Mike
	    if ($sip{$ip} eq undef) {	$sip{$ip} = resolve($ip) };
	}
	$s10{"$user"}++;
    } else {
	$userundef++;
    }
    
    # Unauthorized messages
    if ($status eq '401')
    {
	$s2{"$status�$ip�$url�$user"}++;
    }
    
    # Look for 'dangerous' files successfully downloaded to the client
    # This needs to be modified depending on what system you'r running (unix/VMS/Windows/whatever)
    if ($status eq '200') {
	if ($url =~ m/passwd|\/etc\/shadow|nc.exe|cmd1\.exe|ncx\.exe|inetd|\/services|access\.log|cmd\.exe|\.\%..\%..|\.url|\.bat/ix) {
	    $s3{"$ip�$url"}++;
	}
    }
    
    # Show URL's which have generated a 5xx error
    if ($status =~ m/^5/)
    {
	$s4{"$status�$url"}++;
	$s41{"$status�$url�$ip"}++;
	$s42{"$status�$ip"}++;
	if ($sip{$ip} eq undef) { $sip{$ip} = resolve($ip) };
	$s43{"$date�$ip"}++;
	#print "$date $ip\n";
    }

    # Look for URL's containing non printable characters
    if ($url =~ m/[\x00-\x1f]|[\x7f-\xff]/) 
    {
	#print "$url\n";
	$s45{"$ip\#\#$url"}++;
    }
    
    #Count number of unique IP's, and HITS per IP
    if ($iptab{$ip} eq undef)
    { 
	$numip++;
    }

    # Count hits per IP
    $iptab{$ip}++;
    
    # Count number of statuscodes
    $s5{"$status"}++; 
    
    # Count number of HTTP Versions
    if (defined $httpver) {
	$s6{$httpver}++;
	#print "H:$httpver  Q:$query\n";
    }
    
    # List requests with illegal or missing http version fields. 
    #if ((not $httpver =~ m/^HTTP\/\d\.\d$|N\/A/i) && (defined $httpver))
    if ((not $httpver =~ m/^HTTP\/1.0$|^HTTP\/1.1$|N\/A/i) && (defined $httpver))
    {
	$s61{"$httpver�$ip"}++;
	
    }
    
    # Get Hits per hour
    $s7{$hr}++;
    if ($s7{$hr} > $hrmax) {$hrmax = $s7{$hr}}

    # Look at Referers
    if (defined $referer) {
	unless ($referer =~ m/^\s*$/) { $s11{$referer}++;};
    } else {
	$refererundef++;
    }

    # Count Browser versions
    unless ($browser =~ m/^\s*$/) {$s12{$browser}++;}

    # Check for Cookie Manipulation  - i.e. same cookie from different IP's
    if (defined $cookie) {
	if (($cookie ne '-') && ($cookie ne '')) {
	    #print "Cookie: $cookie   - IP: $ip\n";
	    if (defined $s13{$cookie}) {
		if (($s13{$cookie} ne $ip) && (! defined $s14{"$cookie�$ip"})){
		    #print "Cookie: $cookie \n Old IP: $s13{$cookie} New IP: $ip\n";
		    #Then we have problems...
		    
		    #$s14{"$cookie"}++;
		    $s14{"$cookie�$ip"}++;
		    $s14{"$cookie�$s13{$cookie}"}++;
		} 
		
	    } else {
		#    #print "CIP: $ip\n";
		$s13{$cookie} = $ip;
		#$s14{"$cookie�$ip"}++;
		#$s14{"$cookie�$ip"}++;
		#print "CIP: $cookie = $ip\n";    
		#}
	    }
	}
    } else {
	$cookieundef++;
    }
    
    # Check for unsuccessfull attempts to List directories
    #print "$url\n";
    if (($url =~ m/\/$/) && ($status ne '200') && ($status ne '304') && ($status ne '302')) {
	#print "URL $url $status\n";
	$s15{"$ip�$url�$status"}++;
	$s151{"$ip"}++;
    }
    
    # Check for attempts to manipulate form data. 
    # For example 'SELECT' in the Query, or other 'abnormal' characters
    if ($query =~ m/select|\'|\"|\;|javascript|\>|\</gi) {
	$s16{"$ip�$query"}++;
    }

    # Check for Anonymous Proxy Scanning, i.e. URL starts with 'HTTP...' or  
    # uses CONNECT method
    #if ($_ =~ m/connect/i ) {print $url};
    if (($url =~ m/^[\w]+?\s+HTTP[s]*\:/i) || ($method =~ m/^connect/i)) {
	#print $url;
	$s17{"$ip�$status�$method $url"}++;
    }

    # List HTTP Methods found
    if ($method ne '') {
	$s19{$method}++;
    }

    # Check if Several Servers listed
    if (! defined $serverip) { $serverip = '<No Name>' };
    $s20{"$serverip $sitename"}++;

    # Chech if url contains <SCRIPT > tag for XSS attempts
    if ($url =~ m/\<script/ig) {
	$s21{"$ip�$url"}++;
    }

    #print "stats done\n";
}


sub printall {

    # Check if results are OK, before mailing report
    if ($numlines eq $logformat{'Unknown'}) {
	exit 99;
    }
    slog('Printing text output');
    if ($opt_W) {print OUT "<table border=\"1\"><tr><td colspan=\"2\">\n";}
    print OUT "Security Log File Analysis$CRLF";
    if ($opt_W) {print OUT "</td></tr><tr><td colspan=\"2\">\n";}
    print OUT "SLAC v $VERSION   $SITE$SITE_DIR $CRLF$CRLF";
    if ($opt_W) {print OUT "</td></tr><tr><td>\n";}
    print OUT "Inputfile(s): ";
    if ($opt_W) {print OUT "</td><td>\n";}
    print OUT  join (" ",@list). "$CRLF";
    if ($opt_W) {print OUT "</td></tr><tr><td>\n";}
    #print OUT "Outputfile: $outfile $CRLF";
    print OUT "Log Start: ";
    if ($opt_W) {print OUT "</td><td>\n";}
    print OUT "$mindate$CRLF";
    if ($opt_W) {print OUT "</td></tr><tr><td>\n";}
    print OUT "Log Stopp: ";
    if ($opt_W) {print OUT "</td><td>\n";}
    print OUT "$maxdate$CRLF";
    if ($opt_W) {print OUT "</td></tr><tr><td>\n";}
    #print OUT "Execution started: " . $starttimetext . "$CRLF";
    #print OUT "Execution stopped: " . localtime() . "$CRLF";
    printf OUT "nr of analyzed rows: ";
    if ($opt_W) {print OUT "</td><td>\n";}
    printf OUT "%7d $CRLF", $numlines;
    if ($opt_W) {print OUT "</td></tr><tr><td>\n";}
    #printf OUT "nr of non-analyzed rows:    %7d $CRLF", $logformat{'UNKNOWN'};

    printf OUT "nr of unique IP-addresses: ";
    if ($opt_W) {print OUT "</td><td>\n";}
    printf OUT "%7d $CRLF", $numip;
    if ($opt_W) {print OUT "</td></tr><tr><td colspan=\"2\">\n";}
    print OUT "Rows identified as:$CRLF";
    if ($opt_W) {print OUT "</td></tr><tr><td>\n";}
    foreach $x (keys %logformat) {
	if ($opt_W) {print OUT "<div>\n";}
	printf OUT " %-24s %9d$CRLF", $x, $logformat{$x};
	if ($opt_W) {print OUT "</div>\n";}
    }
    if ($opt_W) {print OUT "</td></tr><tr><td>\n";}
    slog("Nr of Analyzed rows: $numlines");
    if ($opt_W) {print OUT "</td></tr><tr><td>\n";}
    slog("Rows/sec: " . $numlines / (time - $starttime + 1));
    if ($opt_W) {print OUT "</td></tr><tr><td>\n";}
    #printf OUT "nr of analyzed rows/second: %7d $CRLF", $numlines / (time - $starttime + 1);
    #printf OUT "nr of $logformat{'CLF'}\n";
    if ($opt_W) {print OUT "</td></tr><tr><td>\n";}
    if ($opt_N ne '') 
    {  print OUT "Name Resolution has NOT been performed.$CRLF$CRLF"; }
    #else
    #{  print OUT "Name Resolution has been performed.$CRLF$CRLF"; }

    sumhash (\%s20);
    if ($sum gt 0) {
	print OUT "Servers analyzed ($uniq):                Rows$CRLF";
	foreach $x (sort keys %s20 ) {
	    printf OUT "  %-30s %9d$CRLF", $x, $s20{$x};
	}
    }
    if ($opt_W) {print OUT "</td></tr><tr></tr>\n";}
    if ($opt_W) {print OUT "</table>\n";}

    
    # Show number of hits/hour
    print OUT "$CRLF********** Hits / hour ********** $CRLF";
    if ($pdesc eq 1) {
	$desctxt = "This shows the number of Hits per hour. Any sudden drops or increases in traffic can be due to web pounders stealing bandwidth, or an effective Denial of Service.";
	print OUT "$desctxt\n";
    }

    sumhash (\%s7);
    #print OUT "Totally $sum and $uniq unique.$CRLF";
    printf OUT "%7s  %9s$CRLF",  'Hour', 'Hits';
    #foreach $k (sort keys %s7)
    for ($k=0;$k<24;$k++)
    {
	@_ = split "�", $k;
	$hits = $s7{sprintf("%02d", $k)};
	if ($hits eq '') { $hits = '0'};
	printf (OUT "%7d  %9s  %-50s$CRLF",  $_[0], $hits, "*" x ($hits / ($hrmax+1) * 40));
    }
    

    # Dangerous files...
    print OUT "$CRLF********** Successful attempts to retrieve \'Dangerous\' files ********** $CRLF";
    if ($pdesc eq 1) {
        $desctxt = "This could indicate successful attempts to retrieve sensitive files, or possibly execute system commands in the server.";
        print OUT $desctxt;
    }

    sumhash (\%s3);
    if ($uniq gt 0) {
	print OUT "This could inidicate a serious security breach.$CRLF";
	print OUT "Totally $sum and $uniq unique.$CRLF";
	printf OUT "%7s  %-15s  %-50s$CRLF",  'Count', 'Src IP', 'URL' ;
	foreach $k (sort {$s3{$b} <=> $s3{$a}} keys %s3 )
	{
	    @_ = split "�", $k;
	    printf (OUT "%7d  %-15s  %-50s$CRLF",  $s3{$k},$_[0], $_[1]);
	}
    } else {
	printf OUT "None. $CRLF";
    }

    
    # Unauthorized
    print OUT "$CRLF********** Users who have accessed protected pages ********** $CRLF";
    if ($pdesc eq 1) {
	$desctxt = "This shows all users who have accessed password protected pages. Users whi repeatedly access the same page could indicate password brute force attempts.";  
	printf OUT "$desctxt\n";
    }
    sumhash (\%s2);
    if ($uniq gt 0) {
	print OUT "Totally $sum and $uniq unique.$CRLF";
	printf OUT  "%7s  %5s  %-15s  %-9s %s$CRLF", 'Count', 'Status', 'Src IP', 'User', 'URL';
	foreach $k (sort {$s2{$b} <=> $s2{$a}} keys %s2 )
	{
	    @_ = split "�", $k;
	    printf(OUT  "%7d  %5s   %-15s  %-9s %s$CRLF",  $s2{$k},$_[0], $_[1], $_[3], $_[2]);
	}
    } else {
	printf OUT "None. $CRLF";
    }

    
    print OUT "$CRLF********** Logged in Users **********$CRLF";
    if ($pdesc eq 1) {
        $desctxt = "Lists all users who have successfully logged in. Verify that the users are valid.";
        printf OUT "$desctxt\n";
    }
    
    sumhash (\%s10);
    if ($uniq gt 0) {   
	print OUT "Totally $sum and $uniq unique.$CRLF";
	printf(OUT "%9s  %-15s$CRLF",  'Count', 'User');
	foreach $k (sort {$s10{$b} <=> $s10{$a}} keys %s10 )
	{
	    @_ = split "�", $k;
	    printf(OUT "%9d  %-15s$CRLF",  $s10{$k},$_[0]);
	}
    } else {
	if ($userundef gt 0) {
	    printf OUT "Not Available - not logged in log file.$CRLF";
	} else {
	    printf OUT "None. $CRLF";
	}
    }

    print OUT "$CRLF********** Logged in users per IP-address (excl Anonymous) **********$CRLF";
    if ($pdesc eq 1) {
	$desctxt = "Shows the source IP-addresses of successful logins. Make sure all addresses are valid or can be derived.";
	print OUT "$desctxt\n";
    }

    sumhash (\%s1);
    if ($uniq gt 0) {
	print OUT "Totally $sum and $uniq unique.$CRLF";
	printf OUT "%9s  %-15s  %-15s  %s$CRLF",  'Count', 'User', 'Src-IP', 'FQDN';
	foreach $k (sort {$s1{$b} <=> $s1{$a}} keys %s1 )
	{
	    @_ = split "�", $k;
	    printf OUT "%9d  %-15s  %-15s  %s$CRLF",  $s1{$k},$_[0], $_[1], $sip{$_[1]};
	}
    } else {
	if ($userundef gt 0) {
            printf OUT "Not Available - not logged in log file.$CRLF";
        } else {
            printf OUT "None. $CRLF";
        }
    }
    
    # Count of all Statuscodes...
    print OUT "$CRLF********** Count of HTTP statuscodes ********** $CRLF";
    if ($pdesc eq 1) {
	$desctxt = "Shows all Statuscodes. If 404's are missing, this probably indicates a fualty error-page. Excessive 4xx and 5xx codes can indicate problems that need further investigation.";
	print OUT "$desctxt\n";
    }
    sumhash (\%s5);
    
    print OUT "Totally $sum and $uniq unique.$CRLF";
    print OUT "    Count     ( % )     HTTP-Status $CRLF";
    foreach $k (sort keys %s5 )
    {
	@_ = split "�", $k;
	#printf(OUT "Count: %9d (%6.2f%%) HTTP Status: %-4d  %s$CRLF",  $s5{$k},($s5{$k}*100/$sum), $_[0], $STATCODE{$_[0]});
	printf(OUT "%9d (%6.2f%%)    %4s %s$CRLF",  $s5{$k},($s5{$k}*100/$sum), $_[0], $STATCODE{$_[0]});
    }

    # Count of all HTTP Methods...
    print OUT "$CRLF********** Count of HTTP Methods ********** $CRLF";
    if ($pdesc eq 1) {
	$desctxt = "Shows all attempted Methods. GET and POST are most common and normal. Others can indicate reconnossaince attempts, or manipulation attempts, however there are many Methods which are legitimate, depending on server and configuration.";
	print OUT "$desctxt\n";
    }
    sumhash (\%s19);
    print OUT "Totally $sum and $uniq unique.$CRLF";
    print OUT "    Count     ( % )     HTTP-Method $CRLF";
    foreach $k (sort {$s19{$b} <=> $s19{$a}} keys %s19 )
    {
        @_ = split "�", $k;
	printf(OUT "%9d (%6.2f%%)     %s$CRLF",  $s19{$k}, ($s19{$k}*100/$sum),    $k,);
}


    
    # Count of all HTTP Versions...
    print OUT "$CRLF********** Count of HTTP Versions ********** $CRLF";
    if ($pdesc eq 1) {
        $desctxt = "There are basically two (or maybe three) HTTP versions: HTTP/1.0, HTTP/1.1, HTTP/0.9. Anything else is either a faulty browser or reconnossaince / manipulation attempts. Keep an eye on addresses generating invalid HTTP versions.";
	print OUT "$desctxt\n";
    }

    sumhash (\%s6);
    print OUT "Totally $sum and $uniq unique.$CRLF";
    print OUT "    Count     ( % )    HTTP-Version $CRLF";
    foreach $k (sort {$s6{$b} <=> $s6{$a}} keys %s6 )
    {
	@_ = split "�", $k;
	#printf(OUT "Count: %9d %s  %s %s$CRLF",  $s6{$k}, ($s6{$k}*100/$sum), $_[0]);
	printf(OUT "%9d (%6.2f%%)    %s$CRLF",  $s6{$k}, ($s6{$k}*100/$sum), $_[0]);
    }
    
    # List illegal HTTP Versions...
    print OUT "$CRLF********** List illegal HTTP Versions ********** $CRLF";
    if ($pdesc eq 1) {
        $desctxt = "This list all requests done without a valid HTTP versoin. This could indicate attempts to connect via telnet or other tcp based mechanism, usually indicating reconnosaince. Keep an eye on addresses in this list.";
        print OUT "$desctxt\n";
    }

    sumhash (\%s61);
    if ($uniq gt 0) {
	print OUT "Totally $sum and $uniq unique.$CRLF";
	printf(OUT "%9s %-25s %-15s %s %-s$CRLF", 'Count' , 'HTTP String',  'IP', 'FQDN');
	foreach $k (sort {$s61{$b} <=> $s61{$a}} keys %s61 )
	{
	    @_ = split "�", $k;
	    printf(OUT "%9s %-25s %-15s %s  %s$CRLF",  $s61{$k}, $_[0], $_[1], resolve($_[1]));
	}
    } else {
	printf OUT "None. $CRLF";
    }

    # List the Top HIT'ers
    $xx = 1;
    sumhash(\%iptab);
    print OUT "$CRLF$CRLF********** Top " . ( ($uniq > $topmax) ? $topmax : $uniq)  . " HIT\'ers **********$CRLF";
    if ($pdesc eq 1) {
        $desctxt = "This list shows the addresses requesting the most pages (hits). Each hit uses resources - cpu and bandwidth. Top IP's in this list can indicate anything from a valid interested user, to a spider crawling your site looking for security holes. Or someone asking repetitive querys to your database. Keep an eye on the top IP's.";
        print OUT "$desctxt\n";
    }

    #sumhash (\%iptab);
    #print OUT ($uniq >= $topmax) ? $topmax : $uniq;
    print OUT "Totally $sum and $uniq unique.$CRLF";
    printf(OUT "%4s %8s   %7s  %-15s  %-30s$CRLF", 'Rank', '%', 'Count', 'IP', 'FQDN');
    foreach $k (sort {$iptab{$b} <=> $iptab{$a}} keys %iptab )
    {
	@_ = split "�", $k;
	printf(OUT "%4d (%6.2f%%)  %7d  %-15s  %-30s$CRLF", $xx, ($iptab{$k}*100/$sum), $iptab{$k},$_[0], resolve($_[0]));
	if ($xx++ == $topmax) { last; }
    }
    
    
    # List attempts to access non-existing pages
    print OUT "$CRLF$CRLF********** Access attempts generating 403/404 messages **********$CRLF";
    if ($pdesc eq 1) {
	$desctxt = "This list indicates the top requests for nonexistent oages. The tops on this list either indicate faulty links in the sites HTML code, or you are being hit by malicious worms.  ";
        print OUT "$desctxt\n";
    }

    sumhash (\%s01);
    if ($uniq gt 0) {
	print OUT "Totally $sum and $uniq unique.$CRLF";
	printf(OUT "%7s  %7s  %-15s$CRLF",  'Count', 'Status', 'URL');
	foreach $k (sort {$s01{$b} <=> $s01{$a}} keys %s01 )
	{
	    @_ = split "�", $k;
	    printf(OUT "%7d  %7d  %-15s$CRLF",  $s01{$k},$_[0], $_[1]);
	}
	
	print OUT "$CRLF$CRLF********** Top $topmax IP\'s generating 403/404 **********$CRLF";
	if ($pdesc eq 1) {
	    
	    $desctxt = "This list shows the addresses requesting the most nonexistent pages (hits). Each request for a nonexistent page can mean one or more of several things: 1) Someone is actively looking for known security holes on your site. 2) There are faulty links in your HTML code. 3) You are being hit by malicious selfpropagating worms. 4) Someone is preforming reconnossaince of your site. And failing. Bottom line? Top hitters on this list could actively be looking for security holes - monitor their IP's";
	    print OUT "$desctxt\n";
	}
	$xx = 1;
	sumhash (\%s02);
	print OUT "Totally $sum and $uniq unique.$CRLF";
	printf(OUT "%4s %7s   %-15s  %s$CRLF",  'Rank', "Count", "IP-Address", "FQDN");
	foreach $k (sort {$s02{$b} <=> $s02{$a}} keys %s02 )
	{
	    @_ = split "�", $k;
	    #printf(OUT "Count:  %7d  IP: %-15s (%s)$CRLF",  $s02{$k},$_[0], $sip{$_[0]})
	    printf(OUT "%4d %7d   %-15s  %s$CRLF",  $xx, $s02{$k},$_[0], $sip{$_[0]});
	    if ($xx++ == $topmax) { last; }
	}
	
	print OUT "$CRLF$CRLF********** Top $topmax Files per IP genererating 403/404 **********$CRLF";
	if ($pdesc eq 1) {
	    $desctxt = "Is any single IP hammering your site for a non-existent page? Possible Denial-of-Service attempt, or faulty site configuration.";
	    print OUT "$desctxt\n";
	}
	$xx = 1;
	sumhash (\%s0);
	print OUT "Totally $sum and $uniq unique.$CRLF";
	print OUT "This could inidicate either faultly links on your site, or$CRLF";
	print OUT "a perpetrator looking for vulnerabilities.$CRLF";
	printf(OUT "%4s %7s  %-15s  %s$CRLF", 'Rank', 'Count', 'Src IP', 'URL' );
	foreach $k (sort {$s0{$b} <=> $s0{$a}} keys %s0 )
	{
	    @_ = split "�", $k;
	    printf(OUT "%4d %7d  %-15s  %s$CRLF",  $xx, $s0{$k},$_[0], $_[1]);
	    if ($xx++ == $topmax) { last; }
	}
    } else {
        printf OUT "None. $CRLF";
    }
    
	
    
    # 5xx Status
    print OUT "$CRLF********** Top $topmax IP\'s causing Server Errors (5xx) ********** $CRLF";
    if ($pdesc eq 1) {
	$desctxt = "Errors generated here are on the server. This could either be manipulation attempts, or excessive database access. Or just a misconfiguration of the web server.";
	print OUT "$desctxt\n";
    }

    sumhash (\%s42);
    if ($uniq > 0) {
	$xx = 1;
	print OUT "Totally $sum and $uniq unique.$CRLF";
	printf OUT "%7s  %-7s  %-15s %s$CRLF",  'Count', 'Status', 'Src IP', 'FQDN';
	foreach $k (sort {$s42{$b} <=> $s42{$a}} keys %s42 )
	{
	    @_ = split "�", $k;
	    printf(OUT "%7d  %-7d  %-15s %s$CRLF",  $s42{$k},$_[0], $_[1], $sip{$_[1]});
	    if ($xx++ == $topmax) { last; }
	}
   
    
	# 5xx Status
	print OUT "$CRLF********** Top $topmax URL\'s causing Server Errors (5xx) ********** $CRLF";
	if ($pdesc eq 1) {
	    $desctxt = "Errors generated here are on the server. This could either be manipulation attempts, or excessive database access. Or just a misconfiguration of the web server. If the same URL is causing the errors, this might indicate the source of the problem. Or possibly a security breach.";
	    print OUT "$desctxt\n";
	}
	
	$xx = 1;
	sumhash (\%s4);
	print OUT "Totally $sum and $uniq unique.$CRLF";
	printf OUT "%7s  %-7s  %-20s$CRLF",  'Count', 'Status', 'URL';
	foreach $k (sort {$s4{$b} <=> $s4{$a}} keys %s4 )
	{
	    @_ = split "�", $k;
	    printf(OUT "%7d  %-7d  %-20s$CRLF",  $s4{$k},$_[0], $_[1]);
	    if ($xx++ == $topmax) { last; }
	}
	
	print OUT "$CRLF********** Top $topmax URL\'s & IP\'s causing Server Errors (5xx) ********** $CRLF";
	if ($pdesc eq 1) {
            $desctxt = "Is any single IP using a specific URL to wreak havoc on your web server?";
            print OUT "$desctxt\n";
        }

	$xx = 1;
	sumhash (\%s41);
	print OUT "Totally $sum and $uniq unique.$CRLF";
	printf OUT "%7s  %-7s  %-15s  %s$CRLF", 'Count', 'Status', 'Src IP', 'URL' ;
	foreach $k (sort {$s41{$b} <=> $s41{$a}} keys %s41 )
	{
	    @_ = split "�", $k;
	    printf(OUT "%7d  %-7d  %-15s  %s$CRLF",  $s41{$k},$_[0], $_[2], $_[1]);
	    if ($xx++ == $topmax) { last; }
	}
    } else {
        printf OUT "None. $CRLF";
    }


    # Binary / un-printable data in URL's
    print OUT "$CRLF********** URL's containing binary data ********** $CRLF";
    if ($pdesc eq 1) {
	$desctxt = "This is a no-no. Anything listed here should not happen under normal circumstances, since binary data is not allowed in a URL. It should always be encoded in some way. Entries gere could indicate attempts to cause buffer overflows and security breaches. There is a possible false positive with some obscure browsers sending odd binary data, but it is not common. Check these IPs!";
	print OUT "$desctxt\n";
    }
    
    sumhash (\%s45);
    if ($uniq gt 0) {
	print OUT "Totally $sum and $uniq unique.$CRLF";
        printf OUT "%7s  %-15s  %-50s$CRLF",  'Count', 'Src IP', 'URL' ;
        foreach $k (sort {$s45{$b} <=> $s45{$a}} keys %s45 )
        {
            @_ = split "\#\#", $k;
            printf (OUT "%7d  %-15s  %-50s$CRLF",  $s45{$k},$_[0], $_[1]);
        }
    } else {
        printf OUT "None Found. $CRLF";
    }
 
    # Top Referers
    $xx = 1;
    print OUT "$CRLF********** Top $topmax Referers ********** $CRLF";
    if ($pdesc eq 1) {
        $desctxt = "This is mostly for reference, but if your server is vulnerable, someone might have put a link to it on their site. And you will then see where they are coming from (i.e. refered to).";
        print OUT "$desctxt\n";
    }

    sumhash (\%s11);
    if ($uniq > 0 ) {
	print OUT "Totally $sum and $uniq unique.$CRLF";
	printf OUT "%7s  %-50s$CRLF", 'Count', 'Referer' ;
	foreach $k (sort {$s11{$b} <=> $s11{$a}} keys %s11 )
	{
	    @_ = split "�", $k;
	    printf(OUT "%7d  %-50s $CRLF",  $s11{$k},$_[0]);
	    if ($xx++ == $topmax) { last; }
	}
    } else {
        if ($refererundef gt 0) {
            printf OUT "Not Available - not logged in log file.$CRLF";
        } else {
            printf OUT "None. $CRLF";
        }
    }
    
    # Top Browsers
    $xx = 1;
    print OUT "$CRLF********** Browsers ********** $CRLF";
    if ($pdesc eq 1) {
        $desctxt = "This is mostly for reference. The most common browsers are listed in their various formats. However, there are tools which use non-common  brosers. Use of such can be indicative of reconnossaince of the site. Be observant of the top and bottom entries in this list."; 
        print OUT "$desctxt\n";
    }

    sumhash (\%s12);
    if ($uniq > 0 ) {
	print OUT "Totally $sum and $uniq unique.$CRLF";
	printf OUT "%7s  %-50s$CRLF", 'Count', 'Browser' ;
	foreach $k (sort {$s12{$b} <=> $s12{$a}} keys %s12 )
	{
	    @_ = split "�", $k;
	    printf(OUT "%7d  %-50s $CRLF",  $s12{$k},$_[0]);             
	    #if ($xx++ == $topmax) { last; }
	}
    } else {
	printf OUT "Not Available$CRLF";
    }

    # Check for Cookie Manipulation
    $xx = 1;
    print OUT "$CRLF********** Same Cookie from different IP-addresses ********** $CRLF";
    if ($pdesc eq 1) {
        $desctxt = "This could inidicate attempted session hijacking (unlikely, but serious), or users coming via a non-ip session aware proxy (likely, and not so serious).";
        print OUT "$desctxt\n";
    }

    sumhash (\%s14);
    if ($uniq gt 0) {
	print OUT "Totally $sum and $uniq unique. Showing at maximum the top $topmax.$CRLF";
	printf OUT "%9s %-15s %s$CRLF", 'Count', 'IP', 'FQDN';
	#foreach $k (sort {$s14{$b} <=> $s14{$a}} keys %s14)
	$old = '';
	foreach $k (sort keys %s14)
	{
	    #print "\$k: $k\n";
	    @_ = split "�", $k;
	    #print "\$_\[0\]:$_[0]$CRLF";
	    if ($old ne $_[0]) {
		print OUT "$CRLF";
		#$co = $cookie;
		$co = (length($_[0]) > 60) ? substr($_[0],0,20) . ".. [ Truncated ] .." . substr($_[0], length($$_[0])-20,20) : $_[0];
		    
		printf OUT "Cookie: %s$CRLF", $co;
	    }
	    printf OUT "%9d %-15s %s$CRLF", $s14{$k}, $_[1], resolve($_[1]);
	    
	    $old = $_[0];
	    #if ($xx++ == $topmax) { last; }
	}
    } else {
	if ($cookieundef gt 0) {
            printf OUT "Not Available - not logged in log file.$CRLF";
        } else {
            printf OUT "None. $CRLF";
        }
	
    }

    print OUT "$CRLF********** Cross Site Scripting Attempts per IP *********$CRLF";
    if ($pdesc eq 1) {
	$desctxt = "Anything listed here could indicate Cross Site Scripting attempts. If successfull, they could allow stealing of your users credentials, and thus alleviating unauthorized access. Successfull attempts listed here must be examined further.";
	print OUT "$desctxt\n";
    }
    sumhash (\%s21);
    if ($uniq gt 0) {
	print OUT "Totally $sum and $uniq unique.$CRLF";
	printf OUT "%7s %-15s %-40s %-15s$CRLF", 'Count', 'IP', 'URL', 'FQDN';
	foreach $k (sort {$s21{$b} <=> $s21{$a}} keys %s21)
	{
	    ($ip, $url) = split "�", $k;
	    printf OUT "%7d %-15s %-40s %-15s$CRLF",  $s21{$k}, $ip, $url, resolve($ip);
	}
    } else {
        print OUT "None found.$CRLF";
    }


    # Check for Directory scanning / Listing
    $xx = 1;
    print OUT "$CRLF********** Unsuccessful Subdirectory Listing Attempts ********** $CRLF";
    if ($pdesc eq 1) {
	$desctxt = "This indicates reconnosaince buy attempting to list subdirectories of the site. The perpetrator is presumably looking for misconfigured default pages or trying to view source code.";
    }
    sumhash (\%s15);
    if ($uniq gt 0) {
        print OUT "Totally $sum and $uniq unique.$CRLF";
        #print OUT "This could inidicate attempted session hijacking.$CRLF";
        printf OUT "%7s %7s %-40s %-15s %-4s$CRLF", 'Count', 'Status', 'URL', 'IP', 'FQDN';
        foreach $k (sort {$s15{$b} <=> $s15{$a}} keys %s15)
        {
            @_ = split "�", $k;
            printf(OUT "%7d %7s %-40s %-15s %s$CRLF",  $s15{$k},$_[2], $_[1], $_[0], resolve($_[0]));
            if ($xx++ == $topmax) { last; }
        }
    } else {
	print OUT "None found.$CRLF";
    }
    
    
    
    print OUT "$CRLF********** Unsuccessful Subdir attempts per IP ********$CRLF";
    if ($pdesc eq 1) {
        $desctxt = "If the Top IP's generate errors on many subdirectories, it is a probable attempted (and possibly succeeded) reconnossaince sweep.";
	print OUT "$desctxt\n";
    }

    sumhash (\%151);
    if (uniq gt 0) {
	foreach $k (sort {$s151{$b} <=> $s151{$a}} keys %s151) 
	{
	    printf(OUT "Count: %-10s IP: %-15s %s$CRLF", $s151{$k}, $k, resolve($k));
	    foreach $l (keys %s15) {
		($ip2, $url2, $status2) = split "�", $l;
		if ($ip2 eq "$k") {
		    printf OUT "  Subdir: %7s  %4d  %s $CRLF", $s15{$l}, $status2, $url2;
		}
	    }
	    print OUT "$CRLF";
	} 
    } else {
	print OUT "None found.$CRLF";
    }


    # List attempted form manipulation
    $xx = 1;
    print OUT "$CRLF********** Suspected Form Data Manipulation ********** $CRLF";
    if ($pdesc eq 1) {
	$desctxt = "This is basically only valid of the site has a database which can be accessed via SQL. It could indicate attempts to manipluate queries to your database, but could also be a false positive. Needs verification to rule out unauthorized access.";
	printf OUT "$desctxt\n";
    }

    sumhash (\%s16);		     
    if ($uniq gt 0) {
        print OUT "Totally $sum and $uniq unique.$CRLF";
        print OUT "This could inidicate attempted unauthorized database access.$CRLF";
        printf OUT "%7s %-30s %-15s %-15s %-20s$CRLF", 'Count', 'Query', 'IP', 'FQDN' ;
        foreach $k (sort {$s16{$b} <=> $s16{$a}} keys %s16)
        {
            @_ = split "�", $k;
            printf(OUT "%7d %-30s %-15s %-15s$CRLF",  $s16{$k}, $_[1], $_[0], resolve($_[0]));
            if ($xx++ == $topmax) { last; }
        }
    } else {
        print OUT "None found.$CRLF";
    }
    
    # List attempted Anonymous Proxy Scans
    $xx = 1;
    print OUT "$CRLF********** Attempts to locate Proxy ********** $CRLF";
    if ($pdesc eq 1) {
        $desctxt = "This indicates attempts to locate and possibly use the site to stage further attacks. If the proxy attempts are successful, the site could be used to relay spam or participate in illegitimate activities.";
        printf OUT "$desctxt\n";
    }
    
    sumhash (\%s17);
    if ($uniq gt 0) {
        print OUT "Totally $sum and $uniq unique.$CRLF";
        printf OUT "%7s %6s %-40s %-15s %-15s %s$CRLF", 'Count', 'Status', 'Request', 'IP', 'FQDN';
        foreach $k (sort {$s17{$b} <=> $s17{$a}} keys %s17)
        {
            @_ = split "�", $k;
            printf(OUT "%7d %6d %-40s %-15s %s$CRLF",  $s17{$k}, $_[1], $_[2], $_[0], resolve($_[0]));
            if ($xx++ == $topmax) { last; }
        }
    } else {
        print OUT "None found.$CRLF";
    }

    # List exceedingly Long URL's
    $xx = 1;
    print OUT "$CRLF********** Exceedingly Long URL's ********** $CRLF";
    if ($pdesc eq 1) {
        $desctxt = "This indicates attempts to locate and possibly execute a buffer overflow. If sucessful a perpetrator could have full system access. This in not common, but rather there are long URL's on the site which falsely trigger this.";
        printf OUT "$desctxt\n";
    }

    sumhash (\%s18);
    if ($uniq gt 0) {
        print OUT "Totally $sum and $uniq unique.$CRLF";
        printf OUT "%7s %6s %10s  %-15s %-30s %-15s$CRLF", 'Count', 'Status', 'Length', 'URL', 'FQDN' ;
        foreach $k (sort {$s18{$b} <=> $s18{$a}} keys %s18)
        {
            @_ = split "�", $k;
            printf(OUT "%7d %6s %10s  %-30s\n%26s %-15s %s $CRLF",  $s18{$k}, $_[3], $_[2], $_[0] ,'', $_[1], resolve($_[1]));
	    if ($xx++ == $topmax) { last; }
	}
    } else {
	print OUT "None found.$CRLF";
    }
    
    close OUT;
}



sub printxml {
    
    #my $output = new IO::File(">output.xml");
    my $output = new IO::File(">$outfile");
    $w = new XML::Writer(OUTPUT => $output, NEWLINES => 1);
    $w->doctype("report");
    
    # Check if results are OK, before mailing report
    if ($numlines eq $logformat{'Unknown'}) {
	exit 99;
    }
    slog('Printing XML output');
    $w->startTag('report', 'version' => '1.0');
    prntx('version', $VERSION);
    prntx('logdatestart', $mindate);
    prntx('logdateend', $maxdate);
    prntx('title', "Security Log File Analysis");
    prntx('analysisstart', " " . localtime());
    $w->startTag('inputfiles');
    foreach $f (@list) {
	prntx('file',$f);
    }
    $w->endTag('inputfiles');

    prntx('outputfile', $outfile);
    prntx ('execstart', $starttimetext);
    prntx ('execstop', localtime(). "");
    prntx ('rowsanalysed',$numlines);
    prntx ('nripaddr',$numip);
    prntx ('perf',  $numlines / (time - $starttime + 1));
    prntx ('nameresoff', $opt_N);
       
    $w->startTag('logformats');
    $w->characters(prntx('title','Logformats'));

    foreach $x (keys %logformat) {
	$w->startTag("rec");
	prntx ("format", $x);
	prntx ("nrfound", $logformat{$x});
	$w->endTag("rec");
    }

    $w->endTag('logformats');


    slog("Nr of Analyzed rows: $numlines");
    slog("Rows/sec: " . $numlines / (time - $starttime + 1));
    #printf OUT "nr of analyzed rows/second: %7d $CRLF", $numlines / (time - $starttime + 1);
    prntx("rowsanalysedpersec", $numlines / (time - $starttime + 1));

    
    # Show number of hits/hour
   $w->startTag("hitsperhour");
    prntx('title','Hits per hour');
    sumhash (\%s7);
    #print OUT "Totally $sum and $uniq unique.$CRLF";
    #printf OUT "%7s  %9s$CRLF",  'Hour', 'Hits';
    #foreach $k (sort keys %s7)
    #print "<rec>\n";
    for ($k=0;$k<24;$k++)
    {
	@_ = split "�", $k;
	$hits = $s7{sprintf("%02d", $k)};
	if ($hits eq '') { $hits = '0'};
	#printf (OUT "  <hits hour=\"%d\">%s</hits>\n",  $_[0], $hits);
	$w->startTag("rec");
	prntx('hour',$_[0]);
	prntx('hits',$hits);
	$w->endTag("rec");
    }
        
    $w->endTag("hitsperhour");


    # Dangerous files...
    #print OUT "$CRLF********** Successful attempts to retrieve \'Dangerous\' files ********** $CRLF";
    sumhash (\%s3);
    $w->startTag('dangerousfiles', 
		 'total' => $sum,
		 'uniq' => $uniq);
    prntx('title', 'Successful attempts to retrieve Dangerous files');
    prntx('desc', 'This could inidicate a serious security breach.');

    #printf OUT "%7s  %-15s  %-50s$CRLF",  'Count', 'Src IP', 'URL' ;
    foreach $k (sort {$s3{$b} <=> $s3{$a}} keys %s3 )
    {
	@_ = split "�", $k;
	$w->startTag('rec');
	prntx('count',$s3{$k});
	prntx('srcip',$_[0]);
	prntx('url',$_[1]);
	$w->endTag('rec');
    }
    $w->endTag(dangerousfiles);


    
    # Unauthorized
    #print OUT "$CRLF********** Users who have accessed protected pages ********** $CRLF";
    sumhash (\%s2);
    $w->startTag("unauthorized", 'total' => $sum, 'uniq' => $uniq);
    prntx('title', 'Users who have accessed protected page');
    foreach $k (sort {$s2{$b} <=> $s2{$a}} keys %s2 )
    {
	@_ = split "�", $k;
	$w->startTag('rec');
	prntx('count',$s2{$k});
	prntx('status',$_[0]);
	prntx('srcip',$_[1]);
	prntx('user',$_[3]);
	prntx('url',$_[2]);
	$w->endTag('rec');
    }
    $w->endTag('unauthorized');    


    #print OUT "$CRLF********** Logged in Users **********$CRLF";
    sumhash (\%s10);
    
    $w->startTag('logged_in_users', 'total' => $sum, 'uniq' => $uniq);
    prntx('title','Logged in users');
    #print OUT "Totally $sum and $uniq unique.$CRLF";
    #printf(OUT "%9s  %-15s$CRLF",  'Count', 'User');
    foreach $k (sort {$s10{$b} <=> $s10{$a}} keys %s10 )
    {
	@_ = split "�", $k;
	$w->startTag('rec');
	prntx('user',$_[0]);
	prntx('count', $s10{$k});
	$w->endTag('rec');

    }
    $w->endTag('logged_in_users');

    
    # Logged in users per IP-address (excl Anonymous) 
    sumhash (\%s1);
    $w->startTag('logged_in_users_per_ip', 'total' => $sum, 'uniq' => $uniq);

    prntx('title', 'Logged in user per IP-address');
    foreach $k (sort {$s1{$b} <=> $s1{$a}} keys %s1 )
    {
	@_ = split "�", $k;
	$w->startTag('rec');
	prntx('count',$s1{$k});
	prntx('user',$_[0]);
	prntx('srcip',$_[1]);
	prntx('fqdn',$sip{$_[1]});
	$w->endTag('rec');	
    }
    $w->endTag('logged_in_users_per_ip');
        

    # Count of all Statuscodes...
    sumhash (\%s5);
    $w->startTag('statuscodes', 'total' => $sum, 'uniq' => $uniq);
    prntx('title','Statuscodes');
    foreach $k (sort keys %s5 )
    {
        @_ = split "�", $k;
        $w->startTag('rec');
	prntx('count',$s5{$k});
        prntx('status',$_[0]);
        prntx('statusname',$STATCODE{$_[0]});
        $w->endTag('rec');
    }
    $w->endTag('statuscodes');
    


    # Count of all HTTP Methods...
    sumhash (\%s19);
    $w->startTag('httpmethods', 'total' => $sum, 'uniq' => $uniq);
    prntx('title', 'List of HTTP methods found');
    foreach $k (sort {$s19{$b} <=> $s19{$a}} keys %s19 )
    {
	@_ = split "�", $k;
	$w->startTag('rec');
	prntx('count',$s19{$k});
	prntx('method',$k);
	$w->endTag('rec');
    }
    $w->endTag('httpmethods');
    

    
    # Count of all HTTP Versions...
    #print OUT "$CRLF********** Count of HTTP Versions ********** $CRLF";
    sumhash (\%s6);

    $w->startTag('httpversions', 'total' => $sum, 'uniq' => $uniq);
    prntx('title', 'Count of HTTP-verssions');
    foreach $k (sort keys %s6 )
    {
	@_ = split "�", $k;
	$w->startTag('rec');
	prntx('count',$s6{$k});
	prntx('version',$_[0]);
        $w->endTag('rec');
    }
    $w->endTag('httpversions');
        
    
    # List illegal HTTP Versions...
    sumhash (\%s61);
    
    $w->startTag('illegalhttp', 'total' => $sum, 'uniq' => $uniq);
    prntx('title', 'Invalid HTTP-versions');
    foreach $k (sort keys %s61 )
    {
	@_ = split "�", $k;
	$w->startTag('rec');
	prntx('count',$s61{$k});
	prntx('httpstr',$_[0]);
	prntx('srcip',$_[2]);
	prntx('fqdn',resolve($_[2]));
	$w->endTag('rec');
    }
    $w->endTag('illegalhttp');

    
    # List the Top HIT'ers
    $xx = 1;
    sumhash(\%iptab);
    $w->startTag('tophitters', 'total' => $sum, 'uniq' => $uniq);
    prntx('title', 'List of Top Hitters');
    foreach $k (sort {$iptab{$b} <=> $iptab{$a}} keys %iptab )
    {
	@_ = split "�", $k;
	$w->startTag('rec');
	prntx('rank',$xx);
	prntx('count',$iptab{$k});
	prntx('srcip',$_[0]);
	prntx('fqdn',resolve($_[0]));
	
	$w->endTag('rec');
	if ($xx++ == $topmax) { last; }
    }
    $w->endTag('tophitters');
    


    # List attempts to access non-existing pages

    sumhash (\%s01);
    $w->startTag('errors4xx', 'total' => $sum, 'uniq' => $uniq);
    prntx('title', 'Access attempts generating 4xx errors');
    #print OUT "Totally $sum and $uniq unique.$CRLF";
    #printf(OUT "%7s  %7s  %-15s$CRLF",  'Count', 'Status', 'URL');
    foreach $k (sort {$s01{$b} <=> $s01{$a}} keys %s01 )
    {
	@_ = split "�", $k;
	$w->startTag('rec');
	prntx('count',$s01{$k});
	prntx('httpstatus',$_[0]);
	#prntx('url',uri_escape($_[1]));
	prntx('url',$_[1]);
	$w->endTag('rec');
    }
    
    $w->endTag('errors4xx');
    
    
    #Top IP\'s generating 403/404 **********
    $xx = 1;
    sumhash (\%s02);
    $w->startTag('top4xxerrorsperip', 'total' => $sum, 'uniq' => $uniq);
    prntx('title', 'Top 4xx errors per IP');
    foreach $k (sort {$s02{$b} <=> $s02{$a}} keys %s02 )
    {
	@_ = split "�", $k;
	$w->startTag('rec');
	prntx('rank',$xx);
	prntx('count',$s02{$k});
	prntx('srcip',$_[0]);
	prntx('fqdn',$sip{$_[0]});
	$w->endTag('rec');
	if ($xx++ == $topmax) { last; }
    }
    $w->endTag('top4xxerrorsperip');
    
    
    #********** Top $topmax Files per IP genererating 403/404 *********
    $xx = 1;
    sumhash (\%s0);
    $w->startTag('top4xxerrorsperipurl', 'total' => $sum, 'uniq' => $uniq);
    prntx('title', 'Top 4xx errors per IP and URL');
    #print OUT "This could inidicate either faultly links on your site, or$CRLF";
    #print OUT "a perpetrator looking for vulnerabilities.$CRLF";
    foreach $k (sort {$s0{$b} <=> $s0{$a}} keys %s0 )
    {
	@_ = split "�", $k;
	$w->startTag('rec');
	prntx('rank',$xx);
	prntx('count',$s0{$k});
	prntx('srcip',$_[0]);
	prntx('url',$_[1]);

	$w->endTag('rec');
	if ($xx++ == $topmax) { last; }
    }
    $w->endTag('top4xxerrorsperipurl');
    

    # 5xx Status
    #print OUT "$CRLF********** Top $topmax IP\'s causing Server Errors (5xx) ********** $CRLF";
    sumhash (\%s42);

    $w->startTag('top_5xx_errors_per_ip', 'total' => $sum, 'uniq' => $uniq);
    prntx('title', 'Top 5xx errors per IP');
    $xx = 1;
    #print OUT "Totally $sum and $uniq unique.$CRLF";
    #print OUT "This could indicate various attempts to cause your web server$CRLF";
    #print OUT "to produce erronous results.$CRLF";  
    
    foreach $k (sort {$s42{$b} <=> $s42{$a}} keys %s42 )
    {
	@_ = split "�", $k;
	$w->startTag('rec');
	prntx('count',$s42{$k});
	prntx('status',$_[0]);
	prntx('srcip',$_[1]);
	prntx('fqdn',$sip{$_[1]});
	$w->endTag('rec');
	#if ($xx++ == $topmax) { last; }
    }
    
    $w->endTag('top_5xx_errors_per_ip');

    
    
    # 5xx Status
    #******* Top $topmax URL\'s causing Server Errors (5xx) 
    $xx = 1;
    sumhash (\%s4);
    $w->startTag('top_5xx_errors_per_url', 'total' => $sum, 'uniq' => $uniq);
    prntx('title', 'Top 5xx errors per URL');
    #print OUT "Totally $sum and $uniq unique.$CRLF";
    #printf OUT "%7s  %-7s  %-20s$CRLF",  'Count', 'Status', 'URL';
    foreach $k (sort {$s4{$b} <=> $s4{$a}} keys %s4 )
    {
	@_ = split "�", $k;
	$w->startTag('rec');
	prntx('count',$s4{$k});
	prntx('status',$_[0]);
	prntx('url',$_[1]);
	$w->endTag('rec');
	if ($xx++ == $topmax) { last; }
    }
    $w->endTag('top_5xx_errors_per_url');

    
    #print OUT "$CRLF********** Top $topmax URL\'s & IP\'s causing Server Errors (5xx) ********** $CRLF";
    $xx = 1;
    sumhash (\%s41);
    
    $w->startTag('top_5xx_errors_per_ip_url', 'total' => $sum, 'uniq' => $uniq);  
    prntx('title', 'Top 5xx errors per IP and URL');
    #print OUT "Totally $sum and $uniq unique.$CRLF";
    #printf OUT "%7s  %-7s  %-15s  %s$CRLF", 'Count', 'Status', 'Src IP', 'URL' ;
    foreach $k (sort {$s41{$b} <=> $s41{$a}} keys %s41 )
    {
	@_ = split "�", $k;
	$w->startTag('rec');
	prntx('count',$s41{$k});
	prntx('status',$_[0]);
	prntx('srcip',$_[2]);
	prntx('url',$_[1]);
	$w->endTag('rec');
    }

    $w->endTag('top_5xx_errors_per_ip_url');


     
    # Top Referers
    $xx = 1;
    #print OUT "$CRLF********** Top $topmax Referers ********** $CRLF";
    sumhash (\%s11);

    #if ($uniq > 0 ) {
    $w->startTag('topreferers', 'total' => $sum, 'uniq' => $uniq);
    prntx('title', 'Top Referers');
    foreach $k (sort {$s11{$b} <=> $s11{$a}} keys %s11 )
    {
	@_ = split "�", $k;
	$w->startTag('rec');
	
	#$xy = $_[0];
	if ($_[0] =~ m/(.*?)\?(.*)/) {
	    $urlstr = $1; $uristr = uri_escape($2);
	} else {
	    #print "$_[0]\n";
	    $urlstr = $_[0]; $uristr = '';
	}

	#$xy =~ s/\?.*//i;
	#printf(OUT "  <refstr count=\"%d\"  refurl=\"%s\" refuri=\"%s\" />\n",  $s11{$k}, $urlstr, $uristr );
	prntx('count',$s11{$k});
	prntx('refurl',$urlstr);
	prntx('refuri',$uristr);
	$w->endTag('rec');
	#if ($xx++ == $topmax) { last; }
    }
    $w->endTag('topreferers');
        
    
    # Top Browsers
    $xx = 1;
    sumhash (\%s12);
    $w->startTag('topbrowsers', 'total' => $sum, 'uniq' => $uniq);
    prntx('title', 'Top Browsers used');
    foreach $k (sort {$s12{$b} <=> $s12{$a}} keys %s12 )
    {
	@_ = split "�", $k;
	$w->startTag('rec');
	prntx('count',$s12{$k});
	prntx('browser',uri_escape($_[0]));
	$w->endTag('rec');
	#if ($xx++ == $topmax) { last; }
    }
    
    $w->endTag('topbrowsers');


    # Check for Cookie Manipulation
    $xx = 1;
    sumhash (\%s14);

    $w->startTag('cookiemanip', 'total' => $sum, 'uniq' => $uniq);
    prntx('title', 'Suspected Cookie Manipulation');
    #print OUT "Totally $sum and $uniq unique. Showing at maximum the top $topmax.$CRLF";
    #print OUT "This could inidicate attempted session hijacking,$CRLF";
    #print OUT "or users coming via a non-ip session aware proxy.$CRLF";
    
    $old = '';
    foreach $k (sort keys %s14)
    {
	@_ = split "�", $k;
	if ($old ne $_[0]) {
	
	    $co = (length($_[0]) > 60) ? substr($_[0],0,20) . ".. [ Truncated ] .." . substr($_[0], length($$_[0])-20,20) : $_[0];
	    prntx('cookie', $co);
	    
	}
	$w->startTag('cookieinfo');
	prntx('count', $s14{$k});
	prntx('srcip', $_[1]);
	prntx('fqdn', resolve($_[1]));
	$w->endTag('cookieinfo');
	
	
	$old = $_[0];
	#if ($xx++ == $topmax) { last; }
    }
    $w->endTag('cookiemanip');
    

    # Check for Directory scanning / Listing
    $xx = 1;
    sumhash (\%s15);
    $w->startTag('subdirlist', 'total' => $sum, 'uniq' => $uniq);
    prntx('title', 'Subdirectory Listing Attempts');
    foreach $k (sort {$s15{$b} <=> $s15{$a}} keys %s15)
    {
	@_ = split "�", $k;
	$w->startTag('rec');
	prntx('count',$s15{$k});
	prntx('status',$_[2]);
	prntx('url',$_[1]);
	prntx('srcip',$_[0]);
	prntx('fqdn',resolve($_[0]));
	$w->endTag('rec');
	#if ($xx++ == $topmax) { last; }
    }
    $w->endTag('subdirlist');
        

    # List attempted form manipulation
    $xx = 1;
    sumhash (\%s16);
    $w->startTag('formmanip', 'total' => $sum, 'uniq' => $uniq);
    prntx('title', 'List suspected FORM manipulation');
    foreach $k (sort {$s16{$b} <=> $s16{$a}} keys %s16)
    {
	@_ = split "�", $k;
	$w->startTag('rec');
	prntx('count',$s16{$k});
	prntx('query',$_[1]);
	prntx('srcip',$_[0]);
	prntx('fqdn',resolve($_[0]));
	$w->endTag('rec');
    }
    $w->endTag('formmanip');
    

    # List attempted Anonymous Proxy Scans
    $xx = 1;
    sumhash (\%s17);
    $w->startTag('locateproxy', 'total' => $sum, 'uniq' => $uniq);
    prntx('title', 'Attempts to locate Proxy');
    #print OUT "Successfull attempts could indicate that your web server can$CRLF";
    #print OUT "be used for staging Internet Attacks and fraud.$CRLF";
    foreach $k (sort {$s17{$b} <=> $s17{$a}} keys %s17)
    {
	@_ = split "�", $k;
	$w->startTag('rec');
	prntx('count', $s17{$k});
	prntx('status', $_[1]);
	prntx('url', $_[2]);
	prntx('srcip',$_[0]);
	prntx('fqdn',resolve($_[0]));
	$w->endTag('rec');
	if ($xx++ == $topmax) { last; }
    }
    $w->endTag('locateproxy');


    # List exceedingly Long URL's
    $xx = 1;
    sumhash (\%s18);
    $w->startTag('longurlattempt', 'total' => $sum, 'uniq' => $uniq);
    prntx('title', 'Exceedingly Long URLs');
    #print OUT "These could indicate attempts to locate and use Buffer Overflows$CRLF";
    #print OUT "to compromise the Web Server, and shoud be considererd as serious attempts to breach Security.$CRLF";
    
    foreach $k (sort {$s18{$b} <=> $s18{$a}} keys %s18)
    {
	@_ = split "�", $k;
	$w->startTag('rec');
	prntx('count',$s18{$k});
	prntx('status',$_[3]);
	prntx('length',$_[2]);
	prntx('url',$_[0]);
	prntx('srcip',$_[1]);
	prntx('fqdn',resolve($_[1]));
	$w->endTag('rec');
	if ($xx++ == $topmax) { last; }
    }
    
    $w->endTag('longurlattempt');
    $w->endTag('report');
    #$w->endTag('html');
    $w->end();
    
    close OUT;
    slog('Done printing XML Output');
}



# Routine to print Statistics for later analysis
sub printstats {
    print STATS '<?xml version="1.0"?>' . "\n";
    print STATS '<SecSrchRun run="secsrch.pl" version="' . $VERSION . '" xmloutputversion="1.0">' . "\n";
    print STATS "<PeriodStart>$mindate</PeriodStart>\n";
    print STATS "<PeriodEnd>$maxdate</PeriodEnd>\n";
    print STATS "<host>\n";
    print STATS "<hostname>" . $cname . "</hostname>\n";
    print STATS "<numlines>" . $numlines . "</numlines>\n";
    print STATS "<errorlines>" . $logformat{'Unknown'} . "</errorlines>\n";

    print STATS "<httpstats>\n";
    print STATS "<code200>"  ;

    print STATS "</host>\n";
    print STATS "</SecSrchRun>\n";

}


######################
# Below are various routines to ease things up

sub prntx () {
    my ($xmlname, $xmlvalue) = @_ ;
    $w->startTag($xmlname);
    $w->characters($xmlvalue);
    $w->endTag($xmlname);
}

sub sumhash  ()
{
    # Get Total, unique, Max and Min from hash
    $sum = 0; $uniq = 0; 
    undef $max;
    foreach $href (@_)
    {
	while ( ($key, $value) = each %$href ) 
	{
	    $sum = $sum + $value; 
	    $uniq++ ; 
	    if (defined $max) { if ($max < $value ) { $max = $value; }
	    } else { $max = $value; }
	    if (defined $min) { if ($min > $value ) { $min = $value; }         
	    } else { $min = $value; }

	}
    }
}

# Routine 'borrowed' from snort_stat...

sub resolve {
    
    local ($mname, $miaddr, $mhost = shift);
    if (($opt_N eq 1) || ($res eq 'false')) {return ''}
    #if ($opt_N eq 1) {return ''}
    # if (not $res eq 'true') { return $mhost }
    $miaddr = inet_aton($mhost);
    $HOSTS{$mhost} = gethostbyaddr($miaddr, AF_INET);
    if (!$HOSTS{$mhost}) {
	$mname ="";
	#die if $@ && $@ ne "alarm\n";  # propagate errors
	if ($mname =~ /^$/) {
	    $mname = $mhost;
	}
	$HOSTS{$mhost} = $mname;
    }
    return $HOSTS{$mhost};
}

sub slog {
    setlogsock('unix');
    openlog('SecSrch.pl', 'cons,pid', 'local2');
    syslog('info', '%s', @_);
    closelog;
}

sub plog {
    # Generate Debug Log
    open DBG, ">>/tmp/secsrch.dbg";
    print DBG @_;
    close DBG;
}

sub trunc {
    # Function to truncate values?
    local ($f, $l = shift);
    $fl = length($f);
    if ($fl > $l) {
	$d = $fl - $l; 
	$x = substr($f, 0, (($fl/2) - ($d / 2)));
    }

    return $x;

}

sub urlencode () {
    $x = shift;
    $x =~ s/\&/\&amp;/g;
    return $x;
}

sub save_chart {
    my $chart = shift or die "Need a chart!";
    my $name = shift or die "Need a name!";
    local(*OUT);

    my $ext = $chart->export_format;

      open(OUT, ">$name.$ext") or 
	  die "Cannot open $name.$ext for write: $!";
    binmode OUT;
    print OUT $chart->gd->$ext();
    close OUT;
}

sub sanitize {  # Sub to sanitize filenames and check for illegal characters
    my $x = shift;
    print "$x\n";
    my $count = 0;
    if (($x =~ s/[`&'*?^()#$|\>\<\[\]\n\r]//g) gt 0) {
	print "$x\n";
	return 99;

    } else 
    {
	return 0;
    }
} 


# And that's about all there is....
